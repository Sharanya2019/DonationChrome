package com.example.pgm2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Account extends AppCompatActivity {
    TextView view,view2;
    Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        btn1=(Button)findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {

            Intent i=new Intent(Account.this,login.class);


            startActivity(i);

        }

        });
        btn2=(Button)findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {

            Intent i=new Intent(Account.this,RegisterMain.class);


            startActivity(i);

        }

        });
    }
}