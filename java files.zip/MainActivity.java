package com.example.pgm2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.*;


public class MainActivity extends AppCompatActivity {
    TextView t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t2=(TextView)findViewById(R.id.t2);
        t2.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {

            Intent i=new Intent(MainActivity.this,Account.class);


            startActivity(i);

        }

        });




    }
}