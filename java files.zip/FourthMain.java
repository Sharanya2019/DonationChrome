package com.example.pgm2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class FourthMain extends AppCompatActivity {
    Spinner s1;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth_main);
        s1=(Spinner)findViewById(R.id.s1);
        btn=(Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int x = s1.getSelectedItemPosition();
                if (x == 1) {
                    Intent i=new Intent(FourthMain.this,Pickup.class);
                    startActivity(i);


                }
                if(x==2) {
                    Intent i = new Intent(FourthMain.this, payment.class);
                    startActivity(i);


                }
                if(x==3) {
                    Intent i=new Intent(FourthMain.this,Pickup.class);
                    startActivity(i);



                }
                if(x==4) {

                    Intent i = new Intent(FourthMain.this, Pickup.class);
                    startActivity(i);


                }
                else
                { Toast.makeText(FourthMain.this, "Choose any", Toast.LENGTH_SHORT).show(); }
            }


        });

    }
}