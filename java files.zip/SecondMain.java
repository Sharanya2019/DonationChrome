package com.example.pgm2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecondMain extends AppCompatActivity {
    TextView opt1,opt2,opt3,opt4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_main);

        opt1=(TextView)findViewById(R.id.opt1);
        opt1.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {
            Intent i=new Intent(SecondMain.this,ThirdMain.class);
            startActivity(i);
        }
    });
        opt2=(TextView)findViewById(R.id.opt2);
        opt2.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {
            Intent i=new Intent(SecondMain.this,FourthMain.class);
            startActivity(i);
        }
        });
        opt3=(TextView)findViewById(R.id.opt3);
        opt3.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {
            Intent i=new Intent(SecondMain.this,FifthMain.class);
            startActivity(i);
        }
        });
        opt4=(TextView)findViewById(R.id.opt4);
        opt4.setOnClickListener(new View.OnClickListener()
        {   @Override
        public void onClick(View v) {
            Intent i=new Intent(SecondMain.this,SixthMain.class);
            startActivity(i);
        }
        });

}
}